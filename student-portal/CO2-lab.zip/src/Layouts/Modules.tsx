import React from "react";

const Module: React.FC = () => {
  return <div></div>;
};
